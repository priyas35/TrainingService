package com.hcl.training.test.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcl.training.controller.EnrollmentController;
import com.hcl.training.dto.EnrollmentDto;
import com.hcl.training.model.Course;
import com.hcl.training.model.Enrollment;
import com.hcl.training.model.User;
import com.hcl.training.service.EnrollmentService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class EnrollmentControllerTest {

	@Mock
	EnrollmentService enrollmentService;

	@InjectMocks
	EnrollmentController enrollmentController;

	@Test
	public void courseEnrollment() {
		String actual;

		EnrollmentDto enrollmentdto = new EnrollmentDto();
		enrollmentdto.setCourseId(1);
		enrollmentdto.setUserId(0);
		Course course = new Course();
		course.setCourseId(enrollmentdto.getCourseId());
		User user = new User();
		user.setUserId(enrollmentdto.getUserId());
		Mockito.when(enrollmentService.courseEnrollment(enrollmentdto)).thenReturn("User not found");
		actual = enrollmentController.courseEnrollment(enrollmentdto).getBody();
		assertEquals("User not found", actual);

		enrollmentdto = null;
		actual = enrollmentController.courseEnrollment(enrollmentdto).getBody();
		assertEquals("Enter valid input", actual);

		enrollmentdto = new EnrollmentDto();
		enrollmentdto.setUserId(1);
		user.setUserId(enrollmentdto.getUserId());
		course = null;
		Mockito.when(enrollmentService.courseEnrollment(enrollmentdto)).thenReturn("Course not Found");
		actual = enrollmentController.courseEnrollment(enrollmentdto).getBody();
		assertEquals("Course not Found", actual);
		
		enrollmentdto = new EnrollmentDto();
		enrollmentdto.setUserId(1);
		enrollmentdto.setCourseId(1);
		user.setUserId(enrollmentdto.getUserId());
		course=new Course();
		course.setCourseId(enrollmentdto.getCourseId());
		Mockito.when(enrollmentService.courseEnrollment(enrollmentdto)).thenReturn("Enrollment Sucessful");
		actual = enrollmentController.courseEnrollment(enrollmentdto).getBody();
		assertEquals("Enrollment Sucessful", actual);
		
		enrollmentdto = new EnrollmentDto();
		enrollmentdto.setUserId(1);
		enrollmentdto.setCourseId(1);
		user.setUserId(enrollmentdto.getUserId());
		course=new Course();
		course.setCourseId(enrollmentdto.getCourseId());
		Enrollment enrollment = new Enrollment(); 
		enrollment.setCourseId(enrollmentdto.getCourseId());
		Mockito.when(enrollmentService.courseEnrollment(enrollmentdto)).thenReturn("You already enrolled");
		actual = enrollmentController.courseEnrollment(enrollmentdto).getBody();
		assertEquals("You already enrolled", actual);
		

	}

}
