package com.hcl.training.test.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import com.hcl.training.controller.UserController;
import com.hcl.training.dto.UserDto;
import com.hcl.training.model.Enrollment;
import com.hcl.training.service.UserService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserControllerTest {
	
	@Mock
	UserService userService;
	
	@InjectMocks
	UserController userController;
	
	UserDto userdto=null;
	
	@Test
	public void authendicateTest() {
		Object actual;
		
		userdto =null;
		actual=userController.authenticate(userdto).getBody();
		assertEquals("Enter the valid inputs", actual);
		
		userdto=new UserDto();
		userdto.setUserId(1);
		actual=userController.authenticate(userdto).getBody();
		assertEquals("Enter the Password", actual);
		
		userdto.setPassWord("priya");
		userdto.setUserId(0);
		actual=userController.authenticate(userdto).getBody();
		assertEquals("Enter the userID", actual);
		
		userdto.setUserId(1);
		userdto.setPassWord("priya");
		HttpStatus statuscode=userController.authenticate(userdto).getStatusCode();
		assertEquals(HttpStatus.OK, statuscode);
		
		userdto.setUserId(1);
		userdto.setPassWord("ghgh");
		List<Enrollment> lstEnrollments = null;
		Mockito.when(userService.authenticateUser(userdto)).thenReturn(lstEnrollments);
		actual=userController.authenticate(userdto).getBody();
		assertEquals("Authentication Failed", actual);
		
		
		userdto.setUserId(1);
		userdto.setPassWord("priya");
		lstEnrollments = new ArrayList<Enrollment>();
		Mockito.when(userService.authenticateUser(userdto)).thenReturn(lstEnrollments);
		actual=userController.authenticate(userdto).getBody();
		assertEquals("you are not entrolled to any course", actual);
		
		userdto.setUserId(1);
		userdto.setPassWord("priya");
		lstEnrollments = new ArrayList<Enrollment>();
		Mockito.when(userService.authenticateUser(userdto)).thenReturn(lstEnrollments);
		Object lstEnrollments2=userController.authenticate(userdto).getBody();
		assertNotNull(lstEnrollments2);
		
	}

}
