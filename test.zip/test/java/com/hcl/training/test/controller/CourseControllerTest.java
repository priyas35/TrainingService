package com.hcl.training.test.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import com.hcl.training.controller.CourseController;
import com.hcl.training.model.Course;
import com.hcl.training.service.CourseService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CourseControllerTest {
	
	
	
	@InjectMocks
	CourseController courseController;
	
	@Mock
	CourseService courseService;
	
	Course course =null;
	List<Course> lstCourses = null;
	
	@Test
	public void findAllCourseTest() {
		Object actual;
		
		
		
		course=new Course();
		course.setCourseId(1);
		course.setCourseName("java");
		course.setDescription("full stack java");
		course.setDurationInHours(3.0);
		course.setEnrolledMembers(35);
		course.setInstructorName("priya");
		lstCourses=new ArrayList<Course>();
		lstCourses.add(course);
		HttpStatus statuscode=courseController.findAllCourse().getStatusCode();
		assertEquals(HttpStatus.OK, statuscode);
		
		
	    
		actual=courseController.findAllCourse().getBody();
		assertEquals("There is no course", actual);
		
		
		course=new Course();
		course.setCourseId(1);
		course.setCourseName("java");
		course.setDescription("full stack java");
		course.setDurationInHours(3.0);
		course.setEnrolledMembers(35);
		course.setInstructorName("priya");
		lstCourses=new ArrayList<Course>();
		lstCourses.add(course);
		Mockito.when(courseService.getAllCourses()).thenReturn(lstCourses);
		actual=courseController.findAllCourse().getBody();
		assertNotNull(actual);
		
	}
	
	
	
	
	
	@Test
	public void findCourseByCourseId() {
		Object actual;
		
		course=null;
		actual=courseController.searchCourse(1).getBody();
		assertEquals("There is no Course", actual);
		
		course=new Course();
		course.setCourseId(1);
		Mockito.when(courseService.searchCourseByCourseId(1)).thenReturn(course);
		HttpStatus status=courseController.searchCourse(1).getStatusCode();
		assertEquals(HttpStatus.OK, status);
		
	}
	
	
	@Test
	public void findCourseByCourseName() {
		Object actual;
		
		List<Course> lstcourse =null;
		actual=courseController.searchCourseByCourseName("hhbh").getBody();
		assertEquals("There is no Course", actual);
		
		lstcourse=new ArrayList<Course>();
		Mockito.when(courseService.searchCourseByCourseName("java")).thenReturn(lstcourse);
		HttpStatus status=courseController.searchCourseByCourseName("java").getStatusCode();
		assertEquals(HttpStatus.OK, status);
		
		lstcourse=new ArrayList<Course>();
		Mockito.when(courseService.searchCourseByCourseName("pin")).thenReturn(lstcourse);
		status=courseController.searchCourseByCourseName("pinl").getStatusCode();
		assertEquals(HttpStatus.OK, status);
		
		lstcourse=new ArrayList<Course>();
		Mockito.when(courseService.searchCourseByCourseName("java")).thenReturn(lstcourse);
		actual=courseController.searchCourseByCourseName("java").getBody();
		assertNotNull(actual);
		
		  course=null;
		  lstcourse=new ArrayList<Course>();
		  Mockito.when(courseService.searchCourseByCourseName("java")).thenReturn(
		  lstcourse);
		  actual=courseController.searchCourseByCourseName("java").getBody();
		  assertEquals("There is no Course", actual);
		  
		  
		  course=new Course();
		  course.setCourseId(1);
			course.setCourseName("java");
			course.setDescription("full stack java");
			course.setDurationInHours(3.0);
			course.setEnrolledMembers(35);
			course.setInstructorName("priya");
		  lstcourse=new ArrayList<Course>();
		  lstcourse.add(course);
		  
		  Mockito.when(courseService.searchCourseByCourseName("java")).thenReturn(
				  lstcourse);
				  actual=courseController.searchCourseByCourseName("java").getBody();
				  assertNotNull(actual);
		 
		
	}
	
	
	  
	 
	
	
	
	
	
	
	
	

}
