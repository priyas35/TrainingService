package com.hcl.training.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcl.training.model.Course;
import com.hcl.training.repository.CourseRepository;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CourseServiceTest {
	
	
	@Mock
	CourseRepository courseRepository;
	
	@InjectMocks
	CourseServiceImpl courseServiceImpl;
	
	
	
	
	@Test
	public void getAllCoursesTest() {
		
		Course course  = new Course();
		course.setCourseId(1);
		course.setCourseName("java");
		course.setDescription("full stack java");
		course.setDurationInHours(3.0);
		course.setEnrolledMembers(35);
		course.setInstructorName("priya");
		List<Course> lstCourses = new ArrayList<Course>();
		lstCourses.add(course);
		Mockito.when(courseRepository.findAll()).thenReturn(lstCourses);
		List<Course> lstcourse1=courseServiceImpl.getAllCourses();
		assertNotNull(lstcourse1);
		
		
		course=null;
		lstCourses.add(course);
		Mockito.when(courseRepository.findAll()).thenReturn(lstCourses);
		lstcourse1=courseServiceImpl.getAllCourses();
		assertNotNull(lstcourse1);
				
	}
	
	@Test
	public void getCourseByCourseIdTest() {
		Course course  = new Course();
		course.setCourseId(1);
		course.setCourseName("java");
		course.setDescription("full stack java");
		course.setDurationInHours(3.0);
		course.setEnrolledMembers(35);
		course.setInstructorName("priya");
		Mockito.when(courseRepository.findCourseByCourseId(1)).thenReturn(course);
		Course course1=new Course();
		course1=courseServiceImpl.searchCourseByCourseId(1);
		assertNotNull(course1);
		
		course=null;
		Mockito.when(courseRepository.findCourseByCourseId(1)).thenReturn(course);
		course1=new Course();
		course1=courseServiceImpl.searchCourseByCourseId(1);
		assertNull(course1);
		
	}
	
	@Test
	public void searchCourseByCourseNameTest() {
		
		Course course=null;
		List<Course> lstCourses=new ArrayList<Course>();
		Mockito.when(courseRepository.findAll()).thenReturn(lstCourses);
		List<Course>  lstCourses1=new ArrayList<Course>();
		lstCourses1=courseServiceImpl.searchCourseByCourseName("java");
		assertNull(lstCourses1);
		
		
		course  = new Course();
		course.setCourseId(1);
		course.setCourseName("java");
		course.setDescription("full stack java");
		course.setDurationInHours(3.0);
		course.setEnrolledMembers(35);
		course.setInstructorName("priya");
		lstCourses = new ArrayList<Course>();
		lstCourses.add(course);
		Mockito.when(courseRepository.findAll()).thenReturn(lstCourses);
		List<Course> lsCourses=new ArrayList<Course>();
		lsCourses=courseServiceImpl.searchCourseByCourseName("java");
		assertNotNull(lsCourses);
		
		
	}
	
	
	
	
	
	
	
	

}
