package com.hcl.training.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcl.training.dto.UserDto;
import com.hcl.training.model.Enrollment;
import com.hcl.training.model.User;
import com.hcl.training.repository.EnrollmentRepository;
import com.hcl.training.repository.UserRepository;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserServiceTest {
	
	@Mock
	UserRepository userRepository;
	
	@Mock 
	EnrollmentRepository enrollmentRepository;
	
	@InjectMocks
	UserServiceImpl userServiceImpl;
	
	@Test
	public void authenticateTest() {
		User user=new User();
		user.setUserId(1);
		user.setPassWord("priya");
		Mockito.when(userRepository.findUserByUserId(1)).thenReturn(user);
		UserDto userDto=new UserDto();
		userDto.setUserId(1);
		userDto.setPassWord("priya");
		List<Enrollment> result;
		result=userServiceImpl.authenticateUser(userDto);
		assertNotNull(result);
		
		user=new User();
		user.setUserId(1);
		user.setPassWord("priya");
		Mockito.when(userRepository.findUserByUserId(1)).thenReturn(user);
		userDto=new UserDto();
		userDto.setUserId(1);
		userDto.setPassWord("hari");
		result=userServiceImpl.authenticateUser(userDto);
		assertNull(result);
		
		user.setUserId(0);
		user.setPassWord(null);
		Mockito.when(userRepository.findUserByUserId(1)).thenReturn(user);
		userDto=new UserDto();
		userDto.setUserId(1);
		userDto.setPassWord("hari");
		result=userServiceImpl.authenticateUser(userDto);
		assertNull(result);
		
		
		
		
	}

}
