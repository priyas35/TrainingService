package com.hcl.training.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Date;
import java.util.Calendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcl.training.dto.EnrollmentDto;
import com.hcl.training.model.Course;
import com.hcl.training.model.Enrollment;
import com.hcl.training.model.User;
import com.hcl.training.repository.CourseRepository;
import com.hcl.training.repository.EnrollmentRepository;
import com.hcl.training.repository.UserRepository;

@RunWith(MockitoJUnitRunner.Silent.class)
public class EnrollmentServiceTest {
	
	@Mock
	EnrollmentRepository enrollmentRepository;
	
	@Mock
	CourseRepository courseRepository;
	
	@Mock
	UserRepository userRepository;
	
	@InjectMocks
	EnrollmentServiceImpl enrollmentServiceImpl;
	
	@Test
	public void courseEnrollmentTest() {
		EnrollmentDto enrollmentDto=new EnrollmentDto();
		enrollmentDto.setCourseId(1);
		enrollmentDto.setUserId(1);
		User user=new User();
		user.setUserId(1);
		user.setPassWord("priya");
		Course course=new Course();
		course.setCourseId(1);
		course.setCourseName("java");
		course.setDescription("full stack java");
		course.setDurationInHours(3.0);
		course.setEnrolledMembers(35);
		course.setInstructorName("priya");
		Enrollment enrollment= null;
		
		Mockito.when(enrollmentRepository.findEnrollmentByCourseIdAndUserId(1, 1)).thenReturn(enrollment);
		Mockito.when(userRepository.findUserByUserId(1)).thenReturn(user);
		Mockito.when(courseRepository.findCourseByCourseId(1)).thenReturn(course);
		Enrollment enrollment2=new Enrollment();
		enrollment2.setEnrollmentId(1);
		enrollment2.setCourseId(course.getCourseId());
		enrollment2.setCourseName(course.getCourseName());
		enrollment2.setCourseDurationInHours(course.getDurationInHours());
		enrollment2.setDescription(course.getDescription());
		Date date = new Date(Calendar.getInstance().getTime().getTime());
		enrollment2.setEnrollmentDate(date);
		enrollment2.setUserId(user.getUserId());
		enrollment2.setInstructorName(course.getInstructorName());
		enrollment2.setStatus("Enrolled");
		Mockito.when(enrollmentRepository.save(enrollment2)).thenReturn(enrollment2);
		course.setEnrolledMembers(course.getEnrolledMembers()+1);
		Mockito.when(courseRepository.save(course)).thenReturn(course);
		String result;
		result =enrollmentServiceImpl.courseEnrollment(enrollmentDto);
		
		assertEquals("Enrollment Sucessful", result);
		
		
	    enrollmentDto=new EnrollmentDto();
		enrollmentDto.setCourseId(1);
		enrollmentDto.setUserId(1);
		user=new User();
		user.setUserId(1);
		user.setPassWord("priya");
		course=new Course();
		course.setCourseId(1);
		course.setCourseName("java");
		course.setDescription("full stack java");
		course.setDurationInHours(3.0);
		course.setEnrolledMembers(35);
		course.setInstructorName("priya");
		enrollment= new Enrollment();
		enrollment.setCourseId(1);
		enrollment.setUserId(1);
		enrollment.setCourseDurationInHours(3.0);
		enrollment.setDescription("full stack java");
		date = new Date(Calendar.getInstance().getTime().getTime());
		enrollment.setEnrollmentDate(date);
		Mockito.when(enrollmentRepository.findEnrollmentByCourseIdAndUserId(1, 1)).thenReturn(enrollment);
		Mockito.when(userRepository.findUserByUserId(1)).thenReturn(user);
		Mockito.when(courseRepository.findCourseByCourseId(1)).thenReturn(course);
		result =enrollmentServiceImpl.courseEnrollment(enrollmentDto);
		
		assertEquals("You already enrolled", result);
		
		
		user=null;
		Mockito.when(userRepository.findUserByUserId(1)).thenReturn(user);
		result =enrollmentServiceImpl.courseEnrollment(enrollmentDto);
		assertEquals("User not found", result);
		
		user=new User();
		user.setUserId(1);
		user.setPassWord("priya");
		Mockito.when(userRepository.findUserByUserId(1)).thenReturn(user);
		course=null;
		Mockito.when(courseRepository.findCourseByCourseId(1)).thenReturn(course);
		result =enrollmentServiceImpl.courseEnrollment(enrollmentDto);
		assertEquals("Course not Found", result);
		
		
	}

}
